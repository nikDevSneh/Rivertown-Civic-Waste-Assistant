# Rivertown Civic Waste Assistant

An AI prototype that answers residents' waste-disposal questions directly from municipal policy — built for the **1M1B AI for Sustainability Virtual Internship** (in collaboration with IBM SkillsBuild & AICTE).

**Live prototype:** `[add your GitHub Pages / hosted link here]`
**Demo video:** `[add your video link here]`

---

## The problem

> How might we use AI to make local waste-management rules and schedules easily accessible so that citizens comply and illegal dumping decreases?

Municipal waste rules — segregation categories, pickup schedules, hazardous-waste disposal, penalties — are usually scattered across PDFs, notices, and ward-office counters, written in dense administrative language. Residents end up guessing, which leads to mixed waste, missed hazardous-waste pickups, fines, and avoidable illegal dumping.

**SDG alignment:** SDG 11 (Sustainable Cities and Communities), secondary SDG 12 (Responsible Consumption and Production).

## Who this is for

- **Residents** who want a fast, plain-language answer instead of reading a bye-law
- **Municipal bodies** who want fewer repetitive grievance calls and higher compliance
- **Sanitation workers** who benefit from cleaner, correctly segregated waste streams

## How it works

This is a **Retrieval-Augmented Generation (RAG)** prototype:

1. A sample municipal waste policy is split into sections (segregation, collection schedule, e-waste/hazardous disposal, bulk waste, penalties, grievances).
2. When a resident asks a question, a lightweight keyword-overlap retriever scores each policy section and selects the most relevant one(s).
3. Only the retrieved excerpt(s) are passed to the language model as context — never the full document, and never the model's general knowledge.
4. The model answers in plain language and cites the exact policy section it used.
5. If no section matches the question, the assistant says so explicitly rather than guessing.

This keeps answers grounded in the actual policy text instead of a plausible-sounding hallucination — important since the answer has real compliance and legal implications for the resident.

## Responsible AI considerations

| Principle | How this project addresses it |
|---|---|
| **Fairness** | The policy applies uniformly; the assistant doesn't tailor answers by neighborhood, income, or any resident attribute. |
| **Transparency** | The UI visibly shows which policy section was retrieved *before* the model answers — no black-box reasoning. |
| **Ethics** | The assistant only answers waste-policy questions and refuses to guess when no matching section exists. |
| **Privacy** | No personal, location, or household data is collected or stored. Questions are stateless. |

## Tech overview

- Single-file HTML/CSS/JS prototype (`index.html`) — no build step required
- Client-side keyword-overlap retrieval (see `retrieve()` in `index.html`)
- Generation via the Anthropic Claude API (`claude-sonnet-4-6`), called with a system prompt that restricts the model to the retrieved context only

To run locally, simply open `index.html` in a browser (or serve it with any static file server). Note: the live Anthropic API call requires the environment it was built in (Claude.ai artifacts); to reuse this outside that environment, swap the `fetch` call in `callClaude()` for your own API key and endpoint.

## Project deliverables

- `index.html` — working RAG prototype
- `docs/sample-policy.md` — the sample municipal policy text used for retrieval
- Presentation deck — see project submission (title, problem statement, SDG alignment, AI solution overview, responsible AI considerations, expected impact)

## Expected impact

If deployed at ward level: fewer repeat calls to ward offices, faster access to hazardous-waste and bulk-pickup rules (reducing improper disposal), and clearer compliance expectations for residents — reducing avoidable fines and easing the burden on sanitation workers who currently handle poorly segregated waste.

## Author

`[Your Name]` · `[Your College Name]`
1M1B AI for Sustainability Virtual Internship, July–Sep 2026

## License

MIT — see `LICENSE`.
