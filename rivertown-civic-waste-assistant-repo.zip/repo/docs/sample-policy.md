# Rivertown Municipal Solid Waste Bye-Law, 2026 (sample)

This is a fictional sample policy document used to demonstrate the retrieval-augmented generation pipeline in this prototype. It is not a real municipal bye-law. Replace this with your own city/town's actual waste policy to make the project concrete for a real deployment.

## 1. Waste Segregation Categories

All households and establishments must segregate waste into three streams at source: Wet Waste (food scraps, garden waste, biodegradables), Dry Waste (paper, plastic, glass, metal, textiles), and Domestic Hazardous Waste (batteries, expired medicines, paints, chemical containers, sanitary waste). Mixed waste will not be collected.

## 2. Collection Schedule

Wet waste is collected daily between 6:30 AM and 9:00 AM. Dry waste is collected on Tuesdays and Fridays. Domestic hazardous waste is collected on the first Saturday of every month at designated ward collection points only; it must not be placed in regular bins.

## 3. E-Waste & Hazardous Waste Disposal

Batteries, electronics, CFL/LED bulbs, and chemical containers are classified as hazardous or e-waste and are strictly prohibited in blue (dry) or green (wet) bins. Residents must drop these at authorized e-waste kiosks located at each ward office, or hand them to the hazardous-waste collection van on the first Saturday of the month.

## 4. Bulk & Construction Waste

Construction and demolition debris, furniture, and bulk waste exceeding 25 kg are not collected on regular rounds. Residents must book a special pickup through the ward office at least 48 hours in advance; a nominal fee applies based on volume.

## 5. Non-Compliance & Penalties

Failure to segregate waste at source, dumping in public spaces, or placing hazardous waste in regular bins is punishable by a fine ranging from ₹200 for a first offense to ₹1,000 for repeat offenses. Illegal dumping caught on ward CCTV is reported directly to the municipal enforcement cell.

## 6. Grievance Redressal

Missed collections, illegal dumping, or overflowing community bins can be reported via the Rivertown Civic App or the ward helpline. Complaints are acknowledged within 24 hours and resolved within 3 working days.
